import { Component } from "react";

export default class Inicio extends Component {
    render() {
        return <>
         <main>
         <h1>Inicio</h1>
         </main>
       </>
    }
}